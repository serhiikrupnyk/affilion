(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_bf4925a4._.js",
  "static/chunks/4787e_next_dist_compiled_react-dom_8ba0017e._.js",
  "static/chunks/4787e_next_dist_compiled_next-devtools_index_fe030bb1.js",
  "static/chunks/4787e_next_dist_compiled_25146208._.js",
  "static/chunks/4787e_next_dist_client_36029ad0._.js",
  "static/chunks/4787e_next_dist_7efa1f19._.js",
  "static/chunks/61dca_@swc_helpers_cjs_28edb73c._.js"
],
    source: "entry"
});
