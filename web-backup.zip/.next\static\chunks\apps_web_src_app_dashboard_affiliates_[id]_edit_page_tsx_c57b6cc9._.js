(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/apps_web_src_app_dashboard_affiliates_[id]_edit_ui_EditForm_tsx_1d184793._.js"
],
    source: "dynamic"
});
