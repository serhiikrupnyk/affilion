(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/4787e_next_dist_f9a44080._.js",
  "static/chunks/apps_web_src_app_page_module_16f13ab4.css"
],
    source: "dynamic"
});
